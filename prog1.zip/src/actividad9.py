def crear_resultado(resultado):
    return resultado
if __name__=="__main__":
    resultado="el resultado es: "+str((int(input("primer numero: ")) + int(input("segundo numero: ")) + int(input("tercer numero: "))))
    crear_resultado (resultado)
    print (resultado)