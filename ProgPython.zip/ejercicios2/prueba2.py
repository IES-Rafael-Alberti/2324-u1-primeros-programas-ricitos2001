num1 = int(input("Dame un número: "))  
num2 = int(input("Dame otro: "))  
print("La suma " + str(num1) + " + " + str(num2) + " es igual a " + str(num1 + num2))  
print(f"{num1} + {num2} = {num1+num2}")
