edad = input("Introduzca su edad: ")  
if edad >= 18:  
    print("Toma una cerveza!")  
else:  
    print(f"Toma un zumo de piña, con {edad} años eres menor.")
